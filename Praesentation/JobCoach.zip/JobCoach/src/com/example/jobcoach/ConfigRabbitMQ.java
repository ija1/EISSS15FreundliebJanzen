package com.example.jobcoach;

public class ConfigRabbitMQ {
	
	// fh 139.6.255.154
	public static final String IP = "192.168.178.20";
	public static final String USER = "Tester";
	public static final String PASSWORD = "testtest1";
	public static final String EXCHANGE_RATING = "Rating";
	public static final String EXCHANGE_ACTION = "Notfallchat";
	public static final String EXCHANGE_TERMIN = "Termin";
	public static final String EXCHANGE_TYPE = "direct";
	public static final int PORT = 5672; 

}
