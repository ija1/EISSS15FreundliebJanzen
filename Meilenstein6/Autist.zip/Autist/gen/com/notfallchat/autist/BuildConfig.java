/** Automatically generated file. DO NOT MODIFY */
package com.notfallchat.autist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}