package test.rabbit.net;
public class ConfigRabbitMQ {
	 public static final String USERNAME = "Tester";
	 public static final String PASSWORD = "testtest1";
	 public static final String HOSTNAME = "127.0.0.1";
	 public static final int PORT = 5672;
	 public static final String EXCHANGE_NAME = "Overlap";
	 public static final String EXCHANGE_TYPE = "direct";		 
}