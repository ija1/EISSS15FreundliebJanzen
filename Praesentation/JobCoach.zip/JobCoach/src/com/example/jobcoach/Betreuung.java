package com.example.jobcoach;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;  

/**
 * Activity for save new autistics who supervise in userlist.json
 * this class is manly for the user selection in Terminvergabe.java
 * 
 * @author Jan Freundlieb, Irene Janzen (System ABC)
 * @version 2015.01
 */
public class Betreuung extends Activity {
	
	
	/**
     * Method that show autist list
     * 
     * @param savedInstanceState save last Instance state
	 *
     */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.betreuung);
		
		
		if (Profile.fileExistance("userlist.json", getApplicationContext())) {
			List<User> userlist = Profile.getUserList(getApplicationContext(), "userlist.json");
			if (userlist != null) {
			if (!userlist.isEmpty()) {
					LinearLayout l = (LinearLayout) findViewById(R.id.userlist);
					int i=0;
					for (User user : userlist ) {
						
						if(i!=0) {
							
						Button userButton = new Button(getApplicationContext());
						
						
						userButton.setOnClickListener(new OnClickListener() {
							
							public void onClick(View v) {
								Intent i = new Intent(getApplicationContext(), Statistics.class);
								startActivity(i);
							}
						});
						
						userButton.setText(user.getVorName()+","+user.getNachName());
						
						
						
						l.addView(userButton);
						}
						i++;
					}
					Button lastUser= new Button(getApplicationContext());
					
					lastUser.setText(userlist.get(0).getVorName() +"," + userlist.get(0).getNachName());
					
					lastUser.setOnClickListener(new OnClickListener() {
						
						public void onClick(View v) {
							Intent i = new Intent(getApplicationContext(), Statistics.class);
							startActivity(i);
						}
					});
					
					//lastUser.setBackground(background);
					l.addView(lastUser);
				}
			}
		}
		
	}
	
	
	
	public void btnAddUser(View v) throws Exception {
	   Intent i = new Intent(this, AddAutist.class);
	   startActivity(i);
	}
		
	
}
	