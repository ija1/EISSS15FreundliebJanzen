package com.notfallchat.autist;

import android.app.Activity;
import android.os.Bundle;

/**
 * Activity only to show termin dialog
 * 
 * @author Jan Freundlieb, Irene Janzen (System ABC)
 * @version 2015.01
 */
public class ReceiveTermin extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.receivetermin);
    }
}
