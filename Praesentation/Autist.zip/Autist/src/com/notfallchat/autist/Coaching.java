package com.notfallchat.autist;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.notfallchat.autist.MessageConsumer.OnReceiveMessageHandler;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.graphics.PorterDuff.Mode;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.CalendarContract.Events;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Class Mainactivity for the main menu anto consum receiving termins
 * 
 * 
 * @author Jan Freundlieb, Irene Janzen (System ABC)
 * @version 2015.01
 */
public class Coaching extends Activity {
	
	
	private Button kollegen;
	private Button chef;
	private Button meeting;
	private Button HandlungErfragen;
	
	
	// TODO:
	// solve with savedInstanceState parameter
	private boolean consumTerminFlag = false;
	
	
	
	/**
     * Method that call the consumer methods consumTerminfromJobCoach()
     * 
     * @param savedInstanceState save last Instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {


    	super.onCreate(savedInstanceState);
        setContentView(R.layout.coaching);
        setTitle(R.string.app_name);
        
        
        /******************* Main Menu Buttons *******************************/
        final List<String> list = new ArrayList<String>();
        list.add("Kollegen ...");
        list.add("Martin Mueller");
        list.add("Daniel Zimmermann");
        list.add("Jens Neumann");
        
        final Spinner kollegen = (Spinner) findViewById(R.id.kollegen);
        
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		kollegen.setAdapter(dataAdapter);
		
		final List<String> listChef = new ArrayList<String>();
		listChef.add("Arbeitgeber ...");
		listChef.add("Hr. Rudi");
		listChef.add("Hr. Zimmermann");
        
        final List<String> listKategorie = new ArrayList<String>();
        listKategorie.add("Kategorien ...");
        listKategorie.add("Mitarbeiterfrühstück");
        listKategorie.add("Teamarbeit");
        listKategorie.add("Begrüßung");
        listKategorie.add("Verabschiedung");
        
		Spinner chef = (Spinner) findViewById(R.id.arbeitgeber);
        ArrayAdapter<String> dataAdapterChef = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, listChef);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		chef.setAdapter(dataAdapterChef);
         
		Spinner kategorie = (Spinner) findViewById(R.id.kategorie);
        ArrayAdapter<String> dataAdapterKategorie = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, listKategorie);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		kategorie.setAdapter(dataAdapterKategorie);
		
		ImageView search = (ImageView)findViewById(R.id.search);
		search.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				LinearLayout entry = (LinearLayout)findViewById(R.id.entry);
				entry.setVisibility(View.GONE);
				LinearLayout noentry = (LinearLayout)findViewById(R.id.noentry);
				TextView noAction = new TextView(getApplicationContext());
				noAction.setText("Keine Ergebnisse");
				noAction.setTextColor(Color.parseColor("#000000"));
				noentry.addView(noAction);
				Button chat = new Button(getApplicationContext());
				chat.setText("Handlung Anfordern");
				chat.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent i = new Intent(getApplicationContext(),NotfallChat.class);
						startActivity(i);
						
					}
				});
				
				noentry.addView(chat);
				
				
			}
		});
         
        
        
        
        
        
        /**********************************************************************/
        
    }
    
    public void onClickNoEntry(final View sfNormal) {
        //Startet Location Activity
    	Intent i = new Intent(this, NotfallChat.class);
    	//i.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
    	startActivity(i);
    }
    
    
    
    @Override
    protected void onStart() {
    	// TODO Auto-generated method stub
    	super.onStart();
    }
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}
}

